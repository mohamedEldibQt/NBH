@extends('layouts.adminMaster')
@section('title' , 'Dashboard')
@section('content')

    <div class="app-content content">
        <div class="content-wrapper">

            <div class="content-header row">
                <div class="content-header-left col-md-6 col-12 mb-2">
                    <h3 class="content-header-title">{{trans('words.create_about')}}</h3>
                    <div class="row breadcrumbs-top">
                        <div class="breadcrumb-wrapper col-12">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="{{route('about')}}"> {{trans('words.all_about')}}</a>
                                </li>
                                <li class="breadcrumb-item"><a href="{{route('about_trashed')}}"> {{trans('words.about_trashed')}}</a>
                                </li>
                            </ol>
                        </div>
                    </div>
                </div>
                <div class="content-header-right col-md-6 col-12">
                    <div class="btn-group float-md-right" role="group" aria-label="Button group with nested dropdown">

                    </div>
                </div>
            </div>




            <div class="content-body">
                <section id="basic-form-layouts">
                    <div class="row match-height">
                        <div class="col-md-12">
                            <div class="card">
                                <div class="card-header">
                                    <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <li><a data-action="close"><i class="ft-x"></i></a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-content collapse show">
                                    <div class="card-body">
                                        <div class="card-text">
                                            @if(Session::has('success'))
                                                <div class="alert bg-success alert-icon-left alert-arrow-left alert-dismissible mb-2" role="alert">
                                                    <span class="alert-icon"><i class="la la-thumbs-o-up"></i></span>
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                    <strong>Well done!</strong> You  create  successfully
                                                </div>
                                            @elseif(Session::has('error'))
                                                <div class="alert bg-danger alert-icon-left alert-arrow-left alert-dismissible mb-2" role="alert">
                                                    <span class="alert-icon"><i class="la la-thumbs-o-down"></i></span>
                                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                        <span aria-hidden="true">×</span>
                                                    </button>
                                                    <strong>ERROR!</strong> plz check data and tray again
                                                </div>
                                            @endif
                                        </div>




                                        
            



                                      <form   class="form" action="{{route('about_store')}}" method="post"  enctype="multipart/form-data">
                                            @csrf
                                            <div class="form-body">
                                                <h4 class="form-section"><i class="ft-info"></i>{{trans('words.about_info')}} </h4>
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="projectinput1">{{trans('words.about_details')}}</label>
                                                            <input type="text" id="projectinput1" class="form-control" placeholder="{{trans('words.about_details')}}"
                                                                   name="description">
                                                        </div>
                                                    </div>
                                                {{--<div class="col-md-6">
                                                        <div class="form-group">
                                                            <label> {{trans('words.upload_about_img')}}</label> <br>
                                                            <label>Select File</label>
                                                            <label id="projectinput7" class="file center-block">
                                                                <input type="file" id="file" name="about_img" class="form-control">
                                                                <span class="file-custom"></span>
                                                            </label>
                                                        </div>
                                                    </div>  --}}                                                   
                                                </div>




        {{--        <script src="https://code.jquery.com/jquery-3.x-git.min.js"></script>
                <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
                <link href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.css" rel="stylesheet">    
                                                

                <div class="container">    
                      <div class="card">
                        <div class="card-header">Crop and Upload Image</div>
                        <div class="card-body">
                          <div class="form-group">
                            @csrf
                            <div class="row">
                              <div class="col-md-4" style="border-right:1px solid #000000;">
                                <div id="image-preview"></div>
                              </div>
                              <div class="col-md-4" style="padding:75px; border-right:1px solid #000000;">
                                <p><label>Select Image</label></p>
                                <input type="file" name="about_img" id="upload_image" />
                                <br />
                                <br />
                                <button class="btn btn-success crop_image">Crop & Upload Image</button>
                              </div>
                              <div class="col-md-4" style="padding:75px;background-color: #333">
                                <div id="uploaded_image" align="center"></div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <script>  
                        $(document).ready(function(){
                          
                          $image_crop = $('#image-preview').croppie({
                            enableExif:true,
                            viewport:{
                              width:200,
                              height:200,
                              type:'square'
                            },
                            boundary:{
                              width:300,
                              height:300
                            }
                          });
                        
                          $('#upload_image').change(function(){
                            var reader = new FileReader();
                        
                            reader.onload = function(event){
                              $image_crop.croppie('bind', {
                                url:event.target.result
                              }).then(function(){
                                console.log('jQuery bind complete');
                              });
                            }
                            reader.readAsDataURL(this.files[0]);
                          });
                        
                          $('.crop_image').click(function(event){
                            $image_crop.croppie('result', {
                              type:'canvas',
                              size:'viewport'
                            }).then(function(response){
                              var _token = $('input[name=_token]').val();
                              $.ajax({
                                url:'{{ route("about_store") }}',
                                type:'post',
                                data:{"image":response, _token:_token},
                                dataType:"json",
                                success:function(data)
                                {
                                  var crop_image = '<img src="'+data.path+'" />';
                                  $('#uploaded_image').html(crop_image);
                                }
                              });
                            });
                          });
                          
                        });  
                        </script> --}}














            <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.css" />
                <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.5/croppie.min.js"></script>
        
            
            <!-- Create an input field to select the image file -->
            <input type="file" id="image" name="about_img" accept="image/*">
            
            <!-- Create a button to open the modal box -->
            <button type="button" id="crop-btn">Crop Image</button>
            
            <!-- Create the modal box -->
            <div id="modal" style="display: none;">
                <div id="cropper"></div>
                <button type="button" id="save-btn">Save</button>
                <button type="button" id="cancel-btn">Cancel</button>
            </div>
            
            <script>
                // Initialize Croppie.js
                var croppie = new Croppie(document.getElementById('cropper'), {
                    viewport: { width: 200, height: 200 },
                    boundary: { width: 300, height: 300 }
                });
            
                // Handle the click event of the crop button
                document.getElementById('crop-btn').addEventListener('click', function() {
                    // Show the modal box
                    document.getElementById('modal').style.display = 'block';
            
                    // Set the image source
                    var image = document.getElementById('image').files[0];
                    var reader = new FileReader();
                    reader.onload = function(event) {
                        croppie.bind({
                            url: event.target.result
                        });
                    };
                    reader.readAsDataURL(image);
                });
            
                // Handle the click event of the save button
                document.getElementById('save-btn').addEventListener('click', function() {
                    croppie.result({
                        type: 'blob',
                        size: 'viewport',
                        format: 'jpeg'
                    }).then(function(blob) {
                        // Do something with the cropped image blob
                        console.log(blob);
                        // Close the modal box
                        document.getElementById('modal').style.display = 'none';
                    });
                });
            
                // Handle the click event of the cancel button
                document.getElementById('cancel-btn').addEventListener('click', function() {
                    // Close the modal box
                    document.getElementById('modal').style.display = 'none';
                });
            </script>  

{{--
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.2/croppie.min.css">
                    <div class="row">
                        <div class="col-md-4 text-center">
                            <div id="cropie-demo" style="width:250px"></div>
                        </div>
                        <div class="col-md-4" style="padding-top:30px;">
                            <strong>Select Image:</strong>
                            <input type="file" id="upload" name="about_img"> 
                        </div>
    
                    </div>
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/croppie/2.6.2/croppie.js"></script>
            <script type="text/javascript">
                $uploadCrop = $('#cropie-demo').croppie({
                    enableExif: true,
                    viewport: {
                        width: 200,
                        height: 200,
                        type: 'square'
                    },
                    boundary: {
                        width: 300,
                        height: 300
                    }
                });
        
        
                $('#upload').on('change', function() {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $uploadCrop.croppie('bind', {
                            url: e.target.result
                        }).then(function() {
                            console.log('jQuery bind complete');
                        });
                    }
                    reader.readAsDataURL(this.files[0]);
                });
        
        
                $('.upload-result').on('click', function(ev) {
                    $uploadCrop.croppie('result', {
                        type: 'canvas',
                        size: 'viewport',
                        format: 'jpg',
                    }).then(function(resp) {
                        $.ajax({
                            url: "{{ route('about_create') }}",
                            type: "POST",
                            data: {
                                "image": resp
                            },
                            success: function(data) {
                                html = '<img src="' + resp + '" />';
                                $("#image-preview").html(html);
                            }
                        });
                    });
                });
        
            </script>
--}}

                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="projectinput1">  {{trans('words.mission')}}</label>
                                                            <textarea id="issueinput8" rows="5" class="form-control" name="mission" placeholder="{{trans('words.mission')}}"
                                                                      data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="mission"
                                                                      data-original-title="" title="" style="height: 115px;"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label for="projectinput1"> {{trans('words.vision')}}</label>
                                                            <textarea id="issueinput8" rows="5" class="form-control" name="vision" placeholder="{{trans('words.vision')}}"
                                                                      data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="vision"
                                                                      data-original-title="" title="" style="height: 115px;"></textarea>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label for="projectinput1"> {{trans('words.our_value')}}</label>
                                                            <textarea id="issueinput8" rows="5" class="form-control" name="our_value" placeholder="{{trans('words.our_value')}}"
                                                                      data-toggle="tooltip" data-trigger="hover" data-placement="top" data-title="mission"
                                                                      data-original-title="" title="" style="height: 115px;"></textarea>
                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                            <div class="form-actions">
                                                <button type="submit" class="btn btn-primary" id="type-success">
                                                    <i class="la la-check-square-o"></i>  {{trans('words.Save')}}
                                                </button>
                                            </div>
                                        </form> 
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </section>



            </div>

        </div>
    </div>




                               
@endsection
